library("testthat")
library("leiden")

test_check("leiden")
